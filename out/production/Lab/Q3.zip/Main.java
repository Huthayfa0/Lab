//written By Huthayfa Mutan

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Circle c=new Circle();
        Circle a=new Circle("Y",true,5);
        Circle nn=new Circle("R",false,2);
        Circle q= null;
        try {
            q = (Circle) a.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        q.setRadius(6);
        ArrayList<Shape> shapes=new ArrayList<>();
        shapes.add(c);
        shapes.add(a);
        shapes.add(nn);
        shapes.add(q);
        for (Shape i:shapes)
            System.out.println(i);
        Collections.sort(shapes);
        for (Shape i:shapes)
            System.out.println(i);
    }

}
